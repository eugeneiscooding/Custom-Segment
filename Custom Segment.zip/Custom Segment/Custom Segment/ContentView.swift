//
//  ContentView.swift
//  Custom Segment
//
//  Created by Kavsoft on 14/02/20.
//  Copyright © 2020 Kavsoft. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var selected = 0
    
    var body: some View {
       
        VStack(spacing: 8){
            
            Topbar(selected: self.$selected).padding(.top)
            
            if self.selected == 0{
                
                Home()
            }
            else{
                
                Account()
            }
            
        }.background(Color("Color").edgesIgnoringSafeArea(.all))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Topbar : View {
    
    @Binding var selected : Int
    
    var body : some View{
        
        HStack{
            
            Button(action: {
                
                self.selected = 0
                
            }) {
                
                Image("msg")
                    .resizable()
                    .frame(width: 25, height: 25)
                    .padding(.vertical,12)
                    .padding(.horizontal,30)
                    .background(self.selected == 0 ? Color.white : Color.clear)
                    .clipShape(Capsule())
            }
            .foregroundColor(self.selected == 0 ? .pink : .gray)
            
            Button(action: {
                
                self.selected = 1
                
            }) {
                
                Image("acc")
                .resizable()
                .frame(width: 25, height: 25)
                .padding(.vertical,12)
                .padding(.horizontal,30)
                .background(self.selected == 1 ? Color.white : Color.clear)
                .clipShape(Capsule())
            }
            .foregroundColor(self.selected == 1 ? .pink : .gray)
            
            }.padding(8)
            .background(Color("Color2"))
            .clipShape(Capsule())
            .animation(.default)
    }
}

struct Home : View {
    
    var body : some View{
        
        ScrollView(.vertical, showsIndicators: false) {
            
            VStack(spacing: 15){
                
                ForEach(1...8,id: \.self){i in
                    
                    HStack(spacing: 15){
                        
                        Image("pic").renderingMode(.original)
                        
                        VStack(alignment: .leading, spacing: 12) {
                            
                            Text("Catherine")
                            Text("msg \(i)")
                            
                        }
                        
                        Spacer(minLength: 0)
                        
                    }.padding()
                    .background(Color.white)
                }
                
            }.padding()
        }
    }
}

struct Account : View {
    
    var body : some View{
        
        VStack(spacing: 20){
            
            HStack(spacing: 15){
                
                Image("apic").renderingMode(.original)
                
                VStack(alignment: .leading, spacing: 10) {
                    
                    Text("Emma")
                    
                    Text("@emma_18")
                }
                
                Spacer()
            }
            
            
            HStack(spacing: 15){
                
                HStack{
                    
                    VStack(alignment: .leading){
                        
                        Text("Followers").fontWeight(.bold)
                        
                        Text("128").fontWeight(.bold).font(.system(size: 22))
                    }
                    
                    Spacer(minLength: 0)
                    
                }.padding()
                .frame(width: (UIScreen.main.bounds.width - 45) / 2)
                .background(Color.blue)
                .cornerRadius(15)
                
                HStack{
                    
                    VStack(alignment: .leading){
                        
                        Text("Following").fontWeight(.bold)
                        
                        Text("228").fontWeight(.bold).font(.system(size: 22))
                    }
                    
                    Spacer(minLength: 0)
                    
                }.padding()
                .frame(width: (UIScreen.main.bounds.width - 45) / 2)
                .background(Color.pink)
                .cornerRadius(15)
                
            }.foregroundColor(.white)
             .padding(.top)
            
            Button(action: {
                
            }) {
                
                HStack(spacing: 15){
                    
                    Image("map")
                        .renderingMode(.original)
                        .padding()
                        .background(Color("Color1"))
                        .clipShape(Circle())
                    
                    Text("Address")
                    
                    Spacer()
                    
                    Image("arrow").renderingMode(.original)
                    
                }.padding()
                .background(Color.white)
                .foregroundColor(.black)
                
            }.cornerRadius(15)
            .padding(.top)
            
            Button(action: {
                
            }) {
                
                HStack(spacing: 15){
                    
                    Image("world")
                        .renderingMode(.original)
                        .padding()
                        .background(Color("Color1"))
                        .clipShape(Circle())
                    
                    Text("Language")
                    
                    Spacer()
                    
                    Image("arrow").renderingMode(.original)
                    
                }.padding()
                .background(Color.white)
                .foregroundColor(.black)
                
            }.cornerRadius(15)
            
            Button(action: {
                
            }) {
                
                HStack(spacing: 15){
                    
                    Image("log")
                        .renderingMode(.original)
                        .padding()
                        .background(Color("Color1"))
                        .clipShape(Circle())
                    
                    Text("Logout")
                    
                    Spacer()
                    
                    Image("arrow").renderingMode(.original)
                    
                }.padding()
                .background(Color.white)
                .foregroundColor(.black)
                
            }.cornerRadius(15)
            
            Spacer()
            
        }.padding()
        .padding(.top)
    }
}
